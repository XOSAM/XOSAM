
"""
Data Scientist and Machine Learning Engineer Course
General Exercise: Matrix Product Implementation
Author: Sam Katantha
"""

import numpy as np

# Problem 1: Matrices
A = np.array([[-1, 2, 3],
              [4, -5, 6],
              [7, 8, -9]])

B = np.array([[0, 2, 1],
              [0, 2, -8],
              [2, 9, -1]])

# Problem 2: NumPy multiplication
C_matmul = np.matmul(A, B)
C_dot = np.dot(A, B)
C_at = A @ B

print("Matrix product using np.matmul:\n", C_matmul)
print("Matrix product using np.dot:\n", C_dot)
print("Matrix product using @ operator:\n", C_at)

# Problem 3: Single element scratch
c_0_0 = A[0,0]*B[0,0] + A[0,1]*B[1,0] + A[0,2]*B[2,0]
print("Single element c[0,0] =", c_0_0)

# Problem 4: Scratch matrix multiplication function
def matrix_multiply(A, B):
    rows_A, cols_A = A.shape
    rows_B, cols_B = B.shape
    if cols_A != rows_B:
        raise ValueError("Cannot multiply: Number of columns in A must equal number of rows in B")
    C = np.zeros((rows_A, cols_B))
    for i in range(rows_A):
        for j in range(cols_B):
            for k in range(cols_A):
                C[i,j] += A[i,k] * B[k,j]
    return C

C_scratch = matrix_multiply(A, B)
print("Matrix product (scratch implementation):\n", C_scratch)

# Problem 5: Undefined product handling
D = np.array([[-1, 2, 3],
              [4, -5, 6]])
E = np.array([[-9, 8, 7],
              [6, -5, 4]])

try:
    matrix_multiply(D, E)
except ValueError as e:
    print("Error (undefined product):", e)

# Problem 6: Transpose to enable multiplication
E_T = E.T
C_transposed = matrix_multiply(D, E_T)
print("Matrix product after transposing E:\n", C_transposed)
