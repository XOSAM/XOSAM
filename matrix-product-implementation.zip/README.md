
# Matrix Product Implementation

**Course:** Data Scientist and Machine Learning Engineer  
**Author:** Sam Katantha  

## Overview

This repository demonstrates **matrix multiplication** using:

1. Manual calculation (by hand)
2. NumPy functions (`np.matmul`, `np.dot`, `@`)
3. Scratch implementation (from scratch using for loops)
4. Handling undefined products
5. Transposition to enable multiplication

## Files

- `matrix_product.py` : Python script containing all solutions and explanations.
- `outputs/sample_output.txt` : Sample outputs when the script is executed.

## Usage

Run the Python script:

```bash
python matrix_product.py
```

This will display:

- Matrix products using NumPy functions
- Scratch implementation results
- Error handling for undefined products
- Matrix multiplication after transposing
